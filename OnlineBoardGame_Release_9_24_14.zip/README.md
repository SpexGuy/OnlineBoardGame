Online Board Game

Built by Martin Wickham, Joe Klonowski, Scott Hendrickson

Usage:
	These binaries will only run on a computer with Visual Studio installed.

Server:
	To run a server, simply start OBGServerRunner.exe

Client:
	To run a client, run OBGClientRunner.exe
	The client accepts an optional command line argument.  This argument is the ip address of the server to which it should connect.  It defaults to localhost.
	Unfortunately, the client currently cannot connect to a server through a NAT, so it will only work within a LAN.

	If the client cannot connect to the server (or is ever disconnected from the server), it will automatically start a local game.

	If you find that the client is timing out often, one of two things is happening:
	1) You are attempting to connect through a NAT.  This doesn't work.
	2) Either your client or server machine is not fast enough to keep up the required ping, and it is timing out.

Controls:
	(For debug reasons, the mouse pointer is not hidden. The "cursor" from here on refers to the shadow with a red laser at its center, which can be controlled with the mouse.)
	Left click ----------- pick up the topmost object under the cursor
	Right click ---------- drop the last object you picked up
	Shift + Left click --- pick up all objects under the cursor
	Shift + Right click -- drop all objects you are holding
	W/S,A/D,Q/E ---------- Rotate the objects being held
	F -------------------- Lower your cursor to the board
	Z -------------------- Toggle zoom
	R -------------------- Toggle wireframe
	X/esc ---------------- Exit

